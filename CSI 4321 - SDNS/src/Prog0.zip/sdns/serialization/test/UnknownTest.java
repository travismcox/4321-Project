/**
 * 
 */
package sdns.serialization.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author traviscox
 *
 */
class UnknownTest /*extends ResourceRecord*/ {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
