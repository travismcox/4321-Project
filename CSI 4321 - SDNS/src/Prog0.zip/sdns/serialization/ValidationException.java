package sdns.serialization;

public class ValidationException extends Exception {

}
