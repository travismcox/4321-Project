package sdns.serialization;

public class Utility {
	public static long CNAME_TYPE_VALUE = 5;
	public static long NS_TYPE_VALUE = 2;
}
